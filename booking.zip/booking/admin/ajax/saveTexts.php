<?php
include '../common.php';
$langObj->updateTexts();
?>
<script>
	window.parent.hideLoader();
</script>
