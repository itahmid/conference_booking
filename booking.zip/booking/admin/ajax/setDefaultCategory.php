<?php
include '../common.php';

$categoryObj->setDefaultCategory($_GET["category_id"]);

?>